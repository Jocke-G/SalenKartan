Your order have been successfully processed.


Content:
LM - Fastighetskartan Hydrografi


Dataformat:
Vector - shapefile


Note:
Files with a "clean_" file name prefix have been modified by us due to topological errors found in the original files.


CoordinateSystem:
EPSG:3006 (SWEREF99 TM)


License:
FUK(Forskning, utbildning och kulturverksamhet)


Contact:
mail: get.support@slu.se
Twitter: https://twitter.com/support_get


Enjoy your data!

/The GET team.
