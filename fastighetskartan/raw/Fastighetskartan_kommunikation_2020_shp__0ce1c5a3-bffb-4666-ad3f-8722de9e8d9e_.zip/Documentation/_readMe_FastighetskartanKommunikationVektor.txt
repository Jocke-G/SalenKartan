Your order have been successfully processed.


Content:
LM - Fastighetskartan Kommunikation


Dataformat:
Vector - ESRI Shape


CoordinateSystem:
EPSG:3006 (SWEREF99 TM)


License:
FUK(Forskning, utbildning och kulturverksamhet)


Contact:
mail: get.support@slu.se
Twitter: https://twitter.com/support_get


Enjoy your data!

/The GET team.
